# Guia do cppm

## Navegação

1. [Instalação e requisitos](installation.md)
2. [Primeiro projeto](#primeiro-projeto)
3. [Estrutura e manifesto](#estrutura-e-manifesto)
4. [Scripts e argumentos](#scripts-e-argumentos)
5. [Builds e testes](#builds-e-testes)
6. [Bibliotecas e bancos de dados](packages.md)
7. [Templates](#templates)
8. [Lockfile, offline e perfis](#lockfile-offline-e-perfis)
9. [Problemas comuns](#problemas-comuns)
10. [Arquitetura](architecture.md)

## Primeiro projeto

Com CMake, Ninja, compilador C++ e Conan disponíveis:

```sh
cppm doctor
cppm init meu-app
cd meu-app
cppm add fmt
cppm run dev
```

`init` não sobrescreve arquivos do usuário. Um projeto sem dependências
externas pode ser compilado sem Conan. Use `cppm --help` e
`cppm <comando> --help` para consultar as opções.

## Estrutura e manifesto

```text
meu-app/
  cppm.toml
  cppm.lock          # gerado na instalação/build
  CMakeLists.txt
  src/main.cpp
  .cppm/            # arquivos locais; não versionar
```

```toml
[package]
name = "meu-app"
version = "0.1.0"
cpp-standard = 20

[dependencies]
fmt = "11.0.2"

[scripts]
dev = ["cppm", "exec", "--"]
build = ["cppm", "build", "--release"]
test = ["cppm", "test", "--"]
```

O CMake pertence ao projeto e não é reescrito depois de `init`. Adicione targets,
testes, fontes geradas e opções nele. `exec` espera um executável com o nome de
`package.name`. O padrão é C++20; o manifesto aceita 11, 14, 17, 20, 23 e 26,
desde que o compilador e as dependências suportem o padrão escolhido.

## Scripts e argumentos

Arrays executam diretamente, sem shell, no Linux e no Windows. Strings usam
`sh` no Linux e Windows PowerShell no Windows. Os scripts partem da raiz do
projeto, mesmo quando chamados de um subdiretório.

```sh
cppm run
cppm run dev -- "um argumento com espaços"
cppm -C ./outro-projeto run test
```

O `--` separa os argumentos da aplicação das opções do cppm. O status de saída
é preservado para o terminal e para CI. Opções de perfil, offline e lockfile são
herdadas por comandos cppm chamados pelos scripts.

## Builds e testes

```sh
cppm run dev
cppm build --release -j 4
cppm run test
cppm test -- -R app_smoke
```

Debug e Release têm diretórios distintos em `.cppm/build/`. O Conan reutiliza
seu cache compartilhado e o Ninja pode reutilizar objetos. A configuração CMake
é refeita com `--fresh` para aplicar mudanças de dependências e de toolchain.

`cppm run test` executa o CTest; instalar Catch2 ou Google Test não cria casos
de teste automaticamente. Registre seus testes no CMake.

## Templates

```sh
cppm init app-nativo
cppm init minha-api --template drogon
cppm init meu-wasm --template wasm
```

O template nativo cria uma aplicação de console. Drogon cria uma API com rotas
`/` e `/health`, resposta JSON e teste HTTP real. `run dev` usa a porta 8080;
troque com `cppm run dev -- --port 9090`.

WASM exige o SDK Emscripten ativo. `run dev` gera HTML, JS e WASM e serve o
resultado em localhost. `run test` usa Node.js. Bibliotecas Conan nativas não
podem ser instaladas nesse target. Python 3 é usado pelo servidor WASM e pelo
teste HTTP do template Drogon.

## Lockfile, offline e perfis

Versione manifesto, lockfile, CMake e fontes. Ignore `.cppm/`.

```sh
cppm install --frozen-lockfile
cppm exec --offline --frozen-lockfile
cppm build --release --profile ./profiles/ci --frozen-lockfile
```

`--frozen-lockfile` exige um lockfile existente e compatível e não o regrava.
Ele fixa receitas e revisões, não o compilador. `--offline` impede consultas
aos remotos Conan, mas uma receita que precise compilar ainda pode baixar
fontes: a opção não bloqueia a rede de subprocessos.

O perfil padrão é detectado somente se estiver ausente. Perfis existentes não
são sobrescritos. Use um perfil explícito para equipes, opções de bibliotecas
e CI, sempre nos passos de instalação e build.

## Problemas comuns

| Sintoma | O que conferir |
| --- | --- |
| `cppm` não encontrado | `~/.local/bin` no PATH no Linux; abra um terminal novo após o instalador Windows. |
| Conan não encontrado | Instale com `uv tool install 'conan>=2.34,<3'` ou pipx e confira o PATH. |
| Não há `cppm.toml` | Entre na pasta do projeto ou use `-C caminho`. |
| Manifesto e lockfile divergem | Execute `cppm install` sem `--frozen-lockfile` e versione o lockfile atualizado. |
| Dependência não existe no cache offline | Faça primeiro uma instalação online no mesmo perfil e configuração. |
| Conan recusa duas versões | Escolha versões/opções compatíveis para a dependência comum. |
| Receita gráfica pede pacote do sistema | Instale o SDK/pacote de desenvolvimento da plataforma informado pelo Conan. |
| Executável não encontrado | O target CMake executável precisa ter o mesmo nome de `package.name`. |
| Conexão com banco recusada | Confira o servidor, host, porta e autenticação; a instalação fornece o driver cliente. |
| ImGui não abre janela | Configure um backend de janela e renderização e o loop de eventos. |

No Linux, o cppm completa a linkagem de GSSAPI para o libpq 17.11 estático quando
a receita detecta essa biblioteca no sistema. O ajuste coexiste com a correção
de libdecor usada por SDL 3.4 com Wayland.

## Escopo atual

Uma aplicação principal por projeto, dependências com versão exata e backend
Conan 2. Watch, workspaces, registro próprio, cross-compilation e dependências
Conan no WASM ainda não fazem parte desta versão. `add` e `remove` reserializam
o manifesto, portanto comentários do TOML não são preservados.
