# Instalação do cppm

Os pacotes contêm o binário da CLI e um instalador local. Não exigem Rust no
computador que vai usar a ferramenta. CMake, Ninja, Conan 2 e um compilador C++
são requisitos separados.

## Windows x64

Extraia o pacote Windows e execute no PowerShell, dentro da pasta extraída:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

O instalador copia `cppm.exe` para `%LOCALAPPDATA%\Programs\cppm\bin` e registra
esse diretório no `PATH` do usuário, sem privilégios de administrador. Abra um
novo terminal e execute:

```powershell
cppm --version
cppm doctor
```

É possível escolher outra pasta com `-InstallDir` ou omitir a alteração do
PATH com `-NoPath`. Para desinstalar a CLI, execute o `uninstall.ps1` do pacote,
usando o mesmo `-InstallDir` se ele tiver sido personalizado. Projetos, cache
Conan e compiladores são preservados.

Para compilar aplicações, instale Visual Studio Build Tools com a carga
**Desktop development with C++**, incluindo MSVC e Windows SDK. Instale também
CMake 3.24+, Ninja e Conan 2.34+. O cppm encontra o Visual Studio com `vswhere`
e carrega o ambiente MSVC nos subprocessos. Um Developer PowerShell ou um
compilador explícito em `CXX`/`CC` é respeitado.

Se você está usando o repositório em vez de um pacote, instale Rust, compile
e execute o instalador local:

```powershell
cargo build --release --locked
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1
```

O caminho Windows tem código e testes no repositório. A validação de execução
precisa passar no job Windows do CI; uma compilação Linux não valida MSVC.

## Linux

Dentro do pacote extraído:

```sh
sh install.sh
```

O destino padrão é `~/.local/bin/cppm`. Use `--prefix /outra/pasta` para instalar
em `/outra/pasta/bin/cppm`. O instalador não edita arquivos de configuração do
shell. Se a pasta ainda não estiver no PATH, adicione-a permanentemente; no fish:

```fish
fish_add_path ~/.local/bin
```

Instale CMake 3.24+, Ninja e GCC ou Clang pelo gerenciador da distribuição.
Para Conan, use `uv tool install 'conan>=2.34,<3'` ou pipx. No repositório, o
instalador também encontra `target/release/cppm` depois de `cargo build --release`.

## Gerar pacotes

Na plataforma de destino, com Python 3.11+ e Rust instalados:

```sh
cargo build --release --locked
python scripts/package.py
```

São gerados um `.zip` no Windows ou `.tar.gz` no Linux, acompanhados do SHA-256.
O workflow `ci.yml` compila, testa e empacota em runners Linux e Windows.
Os artefatos ficam no próprio workflow. Não há publicação automática de releases,
instalador remoto ou pacote winget/Scoop ainda.

## Pacotes C++

Para projetos sem framework, use `cppm init meu-app`. Também há templates:

```sh
cppm init minha-api --template drogon
cppm init meu-wasm --template wasm
```

No Drogon, `run dev` inicia uma API local com `/health` e `run test` valida uma
resposta HTTP real. O Conan instala Drogon 1.9.14 e suas dependências.

No WASM, instale e ative o SDK Emscripten no terminal. `run dev` compila e serve
o HTML em localhost; `run build` gera os artefatos em
`.cppm/build/wasm-release/bin/`; `run test` usa Node.js. A porta do servidor pode
ser alterada com `cppm run dev -- --port 9090`. Dependências Conan nativas não
podem ser ligadas ao módulo WASM nesta versão.

Neste workspace, o SDK de testes está instalado em
`~/Projetos/cppm/.qa/emsdk`. Para ativá-lo no fish:

```fish
source ~/Projetos/cppm/.qa/emsdk/emsdk_env.fish
```

Para outros ambientes, siga a instalação do
[SDK Emscripten](https://emscripten.org/docs/getting_started/downloads.html).

```sh
cppm init meu-app
cd meu-app
cppm install sqlite
cppm install json
cppm install curl
cppm install sdl
cppm run dev
```

`sqlite` é um alias de `sqlite3`, `json` de `nlohmann_json`, e `curl` de `libcurl`.
JSON usa o header `<nlohmann/json.hpp>` e o tipo `nlohmann::json`.
`sdl` consulta a versão
estável disponível no Conan; `sdl2` e `sdl3` selecionam padrões explícitos de cada
geração. O manifesto recebe uma versão exata e o lockfile fixa o grafo resolvido.
Os metadados CMake da receita configuram includes e linkagem.

O [catálogo organizado](packages.md) inclui MySQL/MariaDB, PostgreSQL, Redis,
MongoDB, SQLite e bibliotecas de rede, interfaces, testes, imagens, matemática,
serialização e paralelismo. O [guia de uso](guide.md) cobre scripts, templates,
perfis, lockfile e problemas comuns.

Bibliotecas com integração ao sistema, como SDL, podem exigir SDKs e bibliotecas
de desenvolvimento da plataforma. Isso é informado pela receita Conan durante
a instalação; o cppm não instala pacotes do sistema com privilégios elevados.
