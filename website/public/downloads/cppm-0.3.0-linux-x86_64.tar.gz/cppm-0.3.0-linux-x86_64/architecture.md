# Arquitetura

A CLI coordena ferramentas existentes. O cppm define o formato do projeto,
as convenções de uso e a integração entre elas; Conan resolve pacotes e
compatibilidade de binários, CMake configura targets e Ninja compila.

## Responsabilidades

| Módulo | Responsabilidade |
| --- | --- |
| `cli` | Argumentos, despacho de comandos e saída para o usuário |
| `manifest` | Modelo do projeto, leitura TOML e validação |
| `packages` | Catálogo pequeno e mapeamento de pacotes para targets CMake |
| `project` | Descoberta da raiz, criação do projeto e exclusão mútua |
| `dependencies` | Operações de adicionar/remover/instalar, lockfile e integração CMake |
| `conan` | Adaptação do manifesto à CLI do Conan 2 |
| `platform` | Ambiente nativo de build; descoberta e ativação MSVC no Windows |
| `build` | Configuração CMake, build Ninja, execução e CTest |
| `process` | Execução de subprocessos, scripts, ambiente e status de saída |
| `storage` | Gravação atômica de arquivos individuais |
| `templates` | Arquivos iniciais e convenções de app, API Drogon e WASM |

Os modelos são estruturas concretas. Ainda existe um único backend de pacotes
e um único caminho de build, portanto não há traits ou factories para backends
hipotéticos. A separação do adaptador Conan permite introduzir outra
implementação quando houver um segundo caso real.

## Adicionar uma dependência

1. Adquire o lock do projeto e relê o manifesto.
2. Normaliza nome e aliases; resolve a versão com Conan quando não há uma explícita ou padrão.
3. Monta o novo manifesto em memória.
4. Instala o grafo com Conan e captura lockfile e metadados em uma pasta temporária.
5. Usa os metadados `cmake_file_name` e `cmake_target_name` para gerar a integração.
6. Grava o manifesto e os arquivos de integração e lockfile.

Falhas de resolução ou compilação da dependência não alteram o manifesto nem o
lockfile versionado. Conan pode ter adicionado arquivos ao seu cache ou à pasta
interna de geradores antes de falhar. O próximo comando reinstala a integração.

Cada arquivo é escrito em um temporário no mesmo filesystem e renomeado.
Isso evita arquivos truncados; não representa uma transação entre vários
arquivos. Um erro de disco durante a etapa de gravação ainda pode exigir
`cppm install` para reconciliar manifesto e lockfile.

## Concorrência e processos

Um lock de arquivo do sistema operacional protege operações que alteram o
projeto. A leitura sob o lock evita usar um manifesto anterior à última
operação concluída. O sistema libera o lock quando o processo termina, mesmo
sem encerramento normal. Comandos concorrentes recebem um erro e podem ser
repetidos.

`run` não segura o lock enquanto executa um script, pois scripts podem chamar
outros comandos cppm. O ambiente registra a cadeia de scripts para detectar
recursão. `exec` libera o lock antes de iniciar a aplicação.

Comandos internos usam argumentos de subprocesso, sem concatenação em shell.
Scripts do manifesto em array usam execução direta, inclusive no Windows.
Scripts em string usam `sh` no Linux ou Windows PowerShell no Windows. Argumentos
externos chegam por parâmetros posicionais no Unix e por JSON e splatting no
PowerShell; não são interpolados no código do script. Para argumentos nativos
com aspas ou regras especiais, os arrays evitam as limitações do shell.
O ambiente de cada subprocesso é configurado diretamente no comando,
sem mutações globais de ambiente no processo Rust.

## Windows

O módulo `platform` respeita um Developer Prompt já ativo ou um compilador
escolhido em `CC`/`CXX`. Caso contrário, encontra Visual Studio com `vswhere`,
executa `VsDevCmd.bat` e captura o ambiente em UTF-16. Esse ambiente é aplicado
apenas aos subprocessos de build e guardado em memória durante o comando.
O caminho descoberto é passado por variável de ambiente para um comando cmd
fixo. A aplicação usa a extensão de executável da plataforma.

Os scripts de instalação são independentes da CLI. O instalador Windows copia
o executável para uma pasta do usuário e atualiza seu PATH persistente. O
empacotamento inclui instalador, binário, licença, instruções e SHA-256, sem
publicação automática. O CI inclui builds e testes nativos em Linux e Windows.

## Verificação

Os testes locais chamam o binário da CLI em diretórios temporários e usam
CMake, Ninja e um compilador reais. Eles cobrem criação sem sobrescrita,
descoberta da raiz, execução, argumentos, status de saída, Debug/Release,
CTest, lockfile congelado, concorrência e falha de instalação. Um Conan
controlado com falha permite verificar que `add` preserva os arquivos originais.

O teste de integração separado utiliza Conan e fmt reais, com compilação e
reutilização offline dos artefatos. Não depende de mock para validar a
integração de pacotes.

## Templates e WebAssembly

O template escolhe arquivos e configuração no momento de `init`. O manifesto
registra `package.target = "wasm"` quando necessário. Builds WASM usam `emcmake`
para configurar a toolchain Emscripten, mantendo CMake e Ninja como backend.
Debug e Release ficam em diretórios separados dos builds nativos.

O template WASM produz HTML, JavaScript e o módulo WASM. O servidor de
desenvolvimento usa o módulo HTTP da biblioteca padrão do Python, limitado a
localhost e à pasta de saída do build. A biblioteca padrão C++ é suportada;
dependências Conan são recusadas nesse target até haver perfis e resolução
separados para Emscripten. Isso impede reutilizar binários nativos por engano.

Drogon mantém o caminho nativo de dependências. Seu teste gerado inicia o servidor
em uma porta local temporária, verifica `/health` e encerra o processo no final.

## Compatibilidade de receitas

A integração mantém um ajuste explícito para SDL 3.4 estático com Wayland no
Linux: o build SDL pode descobrir libdecor do sistema sem que a receita Conan
propague esse vínculo. `cmake/sdl-wayland.cmake` acrescenta o target pkg-config
de libdecor quando disponível. Esse ajuste é limitado ao pacote, versão e
configuração afetados, e é verificado pelo teste real SDL.

O libpq 17.11 estático compilado com Meson pode detectar GSSAPI do sistema sem
propagar essa dependência na receita. `cmake/postgresql-gssapi.cmake` procura a
biblioteca via pkg-config ou `find_library` e completa a linkagem no Linux.
Os ajustes de SDL e PostgreSQL são cumulativos. Builds compartilhados e receitas
no contexto build não recebem o ajuste de libpq.

O catálogo tem versões iniciais fixas, aliases e nomes CMake para consulta.
A instalação continua descobrindo a integração pelos metadados da receita,
inclusive para pacotes com múltiplos componentes como Qt, Boost e Protobuf.
Os aliases de banco selecionam bibliotecas cliente. A CLI não administra
servidores nem provisiona bancos.

No Linux, o build Conan do Qt usa o dialeto GNU do padrão C++ declarado. Isso
habilita as extensões de inteiros exigidas pelo Qt, incluindo `__int128`.
A configuração é limitada ao pacote Qt; o CMake da aplicação continua usando
o padrão ISO declarado, sem habilitar extensões para o código do usuário.

Para dependências diretas de OpenCV, o conanfile gerado define
`opencv/*:with_ffmpeg=False` como padrão inicial. Perfis do Conan podem
sobrescrever essa opção. Isso mantém a instalação básica voltada a imagens
sem exigir toda a cadeia de codecs de áudio e vídeo.

O padrão do cppm para Qt é `shared=True`. Isso mantém os detalhes de bibliotecas
internas do framework dentro de suas bibliotecas dinâmicas, inclusive partes
ausentes nos metadados estáticos da receita Qt 6.12. Um perfil Conan pode
sobrescrever essa opção, assumindo a configuração de linkagem estática.

O plugin PostgreSQL do Qt é desativado no padrão (`with_pq=False`), porque a
receita Qt não completa os vínculos necessários ao libpq estático. O driver
libpq instalado diretamente pelo cppm continua disponível à aplicação.

Para Protobuf nativo, `cmake/protobuf-protoc.cmake` aponta `protobuf::protoc`
para o compilador incluído no mesmo pacote do runtime. Isso evita selecionar
um `protoc` incompatível previamente instalado no PATH. Os builds com schemas
são verificados gerando, compilando e serializando uma mensagem real.

